#include <iostream>
#include <string>

int main()
{
	std::cout << "Exercise on Variables and Conditions";

		std::string name = "Hello my name is Pierre";
		std::string age = "I am 26 years old";
		std::string city = "I live in the province of Quebec";

		int a = 713;
		int b = 22;

		
		std::cout << "Variable Exercise #1__";
		std::cout << "_first integer's value is_";
		std::cout << a;
		std::cout << "_second integer's value is_";
		std::cout << b;

		std::cout << "The sum of the two integers is_";
		std::cout << a + b;
		std::cout << "_The difference of the two integers is_";
		std::cout << a - b;
		std::cout << "_The product of the two integers is_";
		std::cout << a * b;
		std::cout << "_The quotient of the two integers is_";	
		std::cout << a / b;

		std::cout << "Condition Exercise #1__";

		int n = 30;
		if (n % 2 == 0)
		{
			std::cout << "The number is even";
		}
		else 
		{
			std::cout << "The number is odd";
		}

		std::cout << "Condition Exercise #2__";

		int Grade = 13;

		if (Grade >= 16)
		{
			std::cout << "Excellent";
		}
		else if (Grade >= 12)
		{
			std::cout << "Very Good";
		}
		else if (Grade >= 10)
		{
			std::cout << "Passable";
		}
		
		else
		{
			std::cout << "Fail";
		}

		std::cout << "Condition Exercise #3__";

		int c = 7;
		int d = 3;
		int e = 13;

	    if (c > d && c > e)
		{
			std::cout << "The largest number is c" << c;
		}
		else if (d > c && d > e)
		{
			std::cout << "The largest number is d" << d;
		}
		else std::cout << "The largest number is e" << e;


		return 0;
}